﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace class_assignment_lim
{
    public partial class Form2 : Form
    {
        Form1 form1;
        Form2 form2;
        
        public Form2(Form form)
        {
            InitializeComponent();
            form1 = (Form1)form;
        }

        private void btn_addtim_Click(object sender, EventArgs e)
        {
            string tim = txt_tim.Text;
            form1.addtim(tim);
            
        }
    }
}
