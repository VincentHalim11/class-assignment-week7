﻿namespace class_assignment_lim
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dtp_tanggal = new System.Windows.Forms.DateTimePicker();
            this.dtg_hasil = new System.Windows.Forms.DataGridView();
            this.btn_delete = new System.Windows.Forms.Button();
            this.cb_tim1 = new System.Windows.Forms.ComboBox();
            this.cb_tim2 = new System.Windows.Forms.ComboBox();
            this.txt_home = new System.Windows.Forms.TextBox();
            this.txt_away = new System.Windows.Forms.TextBox();
            this.lbl_vs = new System.Windows.Forms.Label();
            this.btn_match = new System.Windows.Forms.Button();
            this.btn_team = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dtg_hasil)).BeginInit();
            this.SuspendLayout();
            // 
            // dtp_tanggal
            // 
            this.dtp_tanggal.Location = new System.Drawing.Point(355, 424);
            this.dtp_tanggal.Name = "dtp_tanggal";
            this.dtp_tanggal.Size = new System.Drawing.Size(462, 31);
            this.dtp_tanggal.TabIndex = 0;
            this.dtp_tanggal.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // dtg_hasil
            // 
            this.dtg_hasil.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtg_hasil.Location = new System.Drawing.Point(19, 21);
            this.dtg_hasil.Name = "dtg_hasil";
            this.dtg_hasil.RowHeadersWidth = 82;
            this.dtg_hasil.RowTemplate.Height = 33;
            this.dtg_hasil.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtg_hasil.Size = new System.Drawing.Size(1170, 381);
            this.dtg_hasil.TabIndex = 1;
            // 
            // btn_delete
            // 
            this.btn_delete.Location = new System.Drawing.Point(33, 424);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(164, 74);
            this.btn_delete.TabIndex = 2;
            this.btn_delete.Text = "Delete";
            this.btn_delete.UseVisualStyleBackColor = true;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // cb_tim1
            // 
            this.cb_tim1.FormattingEnabled = true;
            this.cb_tim1.Location = new System.Drawing.Point(356, 517);
            this.cb_tim1.Name = "cb_tim1";
            this.cb_tim1.Size = new System.Drawing.Size(158, 33);
            this.cb_tim1.TabIndex = 3;
            this.cb_tim1.SelectedIndexChanged += new System.EventHandler(this.cb_tim1_SelectedIndexChanged);
            // 
            // cb_tim2
            // 
            this.cb_tim2.FormattingEnabled = true;
            this.cb_tim2.Location = new System.Drawing.Point(634, 517);
            this.cb_tim2.Name = "cb_tim2";
            this.cb_tim2.Size = new System.Drawing.Size(183, 33);
            this.cb_tim2.TabIndex = 4;
            this.cb_tim2.SelectedIndexChanged += new System.EventHandler(this.cb_tim2_SelectedIndexChanged);
            // 
            // txt_home
            // 
            this.txt_home.Location = new System.Drawing.Point(356, 586);
            this.txt_home.Name = "txt_home";
            this.txt_home.Size = new System.Drawing.Size(158, 31);
            this.txt_home.TabIndex = 5;
            this.txt_home.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_home_KeyPress);
            // 
            // txt_away
            // 
            this.txt_away.Location = new System.Drawing.Point(634, 586);
            this.txt_away.Name = "txt_away";
            this.txt_away.Size = new System.Drawing.Size(192, 31);
            this.txt_away.TabIndex = 6;
            this.txt_away.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_away_KeyPress);
            // 
            // lbl_vs
            // 
            this.lbl_vs.AutoSize = true;
            this.lbl_vs.Location = new System.Drawing.Point(555, 520);
            this.lbl_vs.Name = "lbl_vs";
            this.lbl_vs.Size = new System.Drawing.Size(40, 25);
            this.lbl_vs.TabIndex = 7;
            this.lbl_vs.Text = "VS";
            // 
            // btn_match
            // 
            this.btn_match.Location = new System.Drawing.Point(355, 683);
            this.btn_match.Name = "btn_match";
            this.btn_match.Size = new System.Drawing.Size(159, 71);
            this.btn_match.TabIndex = 8;
            this.btn_match.Text = "Add Match";
            this.btn_match.UseVisualStyleBackColor = true;
            this.btn_match.Click += new System.EventHandler(this.btn_match_Click);
            // 
            // btn_team
            // 
            this.btn_team.Location = new System.Drawing.Point(634, 683);
            this.btn_team.Name = "btn_team";
            this.btn_team.Size = new System.Drawing.Size(192, 71);
            this.btn_team.TabIndex = 9;
            this.btn_team.Text = "Add Team";
            this.btn_team.UseVisualStyleBackColor = true;
            this.btn_team.Click += new System.EventHandler(this.btn_team_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1223, 804);
            this.Controls.Add(this.btn_team);
            this.Controls.Add(this.btn_match);
            this.Controls.Add(this.lbl_vs);
            this.Controls.Add(this.txt_away);
            this.Controls.Add(this.txt_home);
            this.Controls.Add(this.cb_tim2);
            this.Controls.Add(this.cb_tim1);
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.dtg_hasil);
            this.Controls.Add(this.dtp_tanggal);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dtg_hasil)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DateTimePicker dtp_tanggal;
        private System.Windows.Forms.DataGridView dtg_hasil;
        private System.Windows.Forms.Button btn_delete;
        private System.Windows.Forms.ComboBox cb_tim1;
        private System.Windows.Forms.ComboBox cb_tim2;
        private System.Windows.Forms.TextBox txt_home;
        private System.Windows.Forms.TextBox txt_away;
        private System.Windows.Forms.Label lbl_vs;
        private System.Windows.Forms.Button btn_match;
        private System.Windows.Forms.Button btn_team;
    }
}

