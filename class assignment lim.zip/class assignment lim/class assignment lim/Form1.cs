﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Windows.Forms;

namespace class_assignment_lim
{
    public partial class Form1 : Form
    {
        DataTable dt =  new DataTable();
        DataTable home = new DataTable();
        DataTable away = new DataTable();
        Form1 form1;
        Form2 form2;
        
        string simpen;
        string temp;
        public Form1()
        {
            InitializeComponent();
            
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            dt.Columns.Add("Date");
            dt.Columns.Add("Home Team Name");
            dt.Columns.Add("Home Score");
            dt.Columns.Add("Away Score");
            dt.Columns.Add("Away Team Name");

            
            cb_tim1.Items.Add("Boston Celtics");
            cb_tim1.Items.Add("Golden State Warrior");
            cb_tim1.Items.Add("Chicago Bulls");
            cb_tim1.Items.Add("Miami Heat");
            cb_tim1.Items.Add("Orlando magic");

            cb_tim2.Items.Add("Boston Celtics");
            cb_tim2.Items.Add("Golden State Warrior");
            cb_tim2.Items.Add("Chicago Bulls");
            cb_tim2.Items.Add("Miami Heat");
            cb_tim2.Items.Add("Orlando magic");

            dtg_hasil.DataSource = dt;
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
           
        }

        private void txt_home_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void txt_away_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void btn_match_Click(object sender, EventArgs e)
        {
            string score1 = txt_home.Text;
            string score2 = txt_away.Text;
            string tanggal = dtp_tanggal.Value.ToString();

            if (score1 == "" || score2 == "" || cb_tim1.Text == ""||cb_tim2.Text == "")
            {
                MessageBox.Show("harus terisi");

            }
            else
            {
                dt.Rows.Add(tanggal, cb_tim1.Text, score1, score2, cb_tim2.Text);
            }
            

        }

        private void cb_tim1_SelectedIndexChanged(object sender, EventArgs e)
        {
            

        }
        private void cb_tim2_SelectedIndexChanged(object sender, EventArgs e)
        {
            temp = cb_tim2.Text;    
        }

        private void btn_team_Click(object sender, EventArgs e)
        {
            form2 = new Form2(this);
            form2.ShowDialog();
        }

        public void addtim(string namatim)
        {
            int count = 0;
            foreach (string nama in cb_tim1.Items)
            {
               
                if (nama.Equals(namatim))
                {
                    MessageBox.Show("ada yang kembar");
                    count++;

                }
            }
            if (count == 0)
            {
                cb_tim1.Items.Add(namatim);
                cb_tim2.Items.Add(namatim);
            }

            form2.Close();
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            foreach(DataGridViewRow row in dtg_hasil.SelectedRows)
            {
                dtg_hasil.Rows.RemoveAt(row.Index);
            }


        }
    }
}
